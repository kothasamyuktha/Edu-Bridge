package com.discount.Entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="discount_tbl")
public class discount {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private double discount;
	@Column
	private double price;
	
	public double getDiscount() {
	return discount;
}

public void setDiscount(double discount) {
	this.discount = discount;
}


public double getPrice() {
	return price;
}

public void setPrice(double price) {
	this.price = price;
}

public discount(double discount, double price) {
	super();
	this.discount = discount;
	this.price = price;
}

public discount() {
	//super();
	// TODO Auto-generated constructor stub
}

}
